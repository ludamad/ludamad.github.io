#include <iostream>
#include <iomanip>
#include <sstream>
#include "textdisplay.h"

using namespace std;

int DUNGEONHEIGHT = 25;
int DUNGEONWIDTH = 79;

///
TextDisplay::TextDisplay(char cl){
	theDisplay = new char* [DUNGEONHEIGHT]; // Initialize theDisplay
	for(int r = 0; r < DUNGEONHEIGHT; r++){
		theDisplay[r] = new char[DUNGEONWIDTH];
		for(int c = 0; c < DUNGEONWIDTH; c++){
			theDisplay[r][c] = ' ';
		}
	}

    if(cl == 'k'){
        playerClass = "Knight";
        HP = 100;
        MaxHP = 100;
        ATK = 50;
        DEF = 50;
    } else if (cl == 'w'){
        playerClass = "Wizard";
        HP = 60;
        MaxHP = 60;
        ATK = 25;
        DEF = 0;
    } else if (cl == 's'){
        playerClass = "Samurai";
        HP = 80;
        MaxHP = 80;
        ATK = 50;
        DEF = 15;
    }

    GP = 0;
    turn = 1;
    flr = 1;
}

TextDisplay::~TextDisplay(){
	for(int i = 0; i < DUNGEONHEIGHT; i++){ // free char array
		delete [] theDisplay[i];
	}
    delete [] theDisplay;
}

void TextDisplay::notifyGameBoard(int r, int c, char ch){
	theDisplay[r][c] = ch;
}

void TextDisplay::notifyHP(int stat){
	HP = stat;
}

void TextDisplay::notifyDEF(int stat){
	DEF = stat;
}

void TextDisplay::notifyATK(int stat){
	ATK = stat;
}

void TextDisplay::notifyGP(int stat){
	GP = stat;
}

void TextDisplay::notifyTurn(int t){
	turn = t;
}

void TextDisplay::notifyFloor(int f){
	flr = f;
}

char TextDisplay::getDisplay(int x, int y){
	return theDisplay[x][y];
}

void TextDisplay::print(){
	for(int r = 0; r < DUNGEONHEIGHT; r++){
		for (int c = 0; c < DUNGEONWIDTH; c++){
			cout << theDisplay[r][c];
		}
		cout << endl;
	}

    stringstream num;
    num << HP << "/" << MaxHP;
    string fullatk = num.str();
    stringstream num2;
    num2 << DEF;
    string fulldef = num2.str() + "%";

    cout << "      Class: " << setw(7) << left << playerClass << "      " << "GP: " << setw(4) << left << GP << "           " << "Floor: " << flr << endl;
    cout << "      HP: " ;
    cout << setw(7) << left << fullatk;
    cout << "         " << "Atk: " << setw(3) << left << ATK << "           " << "Def: " << setw(4) << left << fulldef << "    ";
    cout << "Turn: " << setw(3) << left << turn << endl;
    std::cout << "\nWhat will you do?" << std::endl;
}

std::string TextDisplay::getPlayerClass(){
	return this->playerClass;
}

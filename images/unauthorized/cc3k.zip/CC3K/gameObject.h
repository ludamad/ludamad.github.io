#ifndef GAME_OBJECT_H
#define GAME_OBJECT_H

#include "cell.h"

// forward declaration because mutual reference
class Cell;

// add public/private/protected members as necessary
class gameObject {
    protected: 
        Cell * _location;
        char _display;

    public:
        gameObject();
        int getX() const;  // getters
        int getY() const;
        char getDisplay();
          //called every turn //TODO: figure out how to use
        void setCell(Cell* cell);
        virtual ~gameObject();
        Cell * getLocation();
};

#endif

#include "player.h"

Player::Player(){
  _display = '@';
}

void Player::regenerateHealth(){
  this->setHealth(fmin(this->maxHP, this->getHealth() + 5));
}

void Player::pickUpGold(Gold * gold){
  switch(gold->pickUp()){
    case 'P':
      this->takeGoldPile();
    break;
    case 'H':
      this->takeDragonHoard();
    break;
    default:
    break;
  }
}

int Player::getGP(){
  return this->gold;
}

void Player::takeGoldPile(){
  this->gold += 10;
}

void Player::takeDragonHoard(){
  this->gold += 50;
}


void Player::checkMove(std::string dir){
    if(dir == "nw" &&
       this->_location->getNeighbour(0)->playerWalkable()){
       this->move(this->_location->getNeighbour(0));
    } else
    if(dir == "no" &&
       this->_location->getNeighbour(1)->playerWalkable()){
       this->move(this->_location->getNeighbour(1));
    } else
    if(dir == "ne" &&
       this->_location->getNeighbour(2)->playerWalkable()){
       this->move(this->_location->getNeighbour(2));
    } else
    if(dir == "we" &&
       this->_location->getNeighbour(3)->playerWalkable()){
       this->move(this->_location->getNeighbour(3));
    } else
    if(dir == "ea" &&
       this->_location->getNeighbour(4)->playerWalkable()){
       this->move(this->_location->getNeighbour(4));
    } else
    if(dir == "sw" &&
       this->_location->getNeighbour(5)->playerWalkable()){
       this->move(this->_location->getNeighbour(5));
    } else
    if(dir == "so" &&
       this->_location->getNeighbour(6)->playerWalkable()){
       this->move(this->_location->getNeighbour(6));
    } else
    if(dir == "se" &&
       this->_location->getNeighbour(7)->playerWalkable()){
       this->move(this->_location->getNeighbour(7));
    }

    else{
       // std::cerr << "can't move there" << std::endl; // DEBUG
        throw("can't move there");
    }
}

//helper function for wizard attack
Cell * Player::getAttackCell(std::string direction){
    Cell* attack_cell = this->_location;

    while(true){
        if (direction == "nw"){
            attack_cell = attack_cell->getNeighbour(0);
        }
        else if (direction == "no"){
            attack_cell = attack_cell->getNeighbour(1);
        }
        else if (direction == "ne"){
            attack_cell = attack_cell->getNeighbour(2);
        }
        else if (direction == "we"){
            attack_cell = attack_cell->getNeighbour(3);
        }
        else if (direction == "ea"){
            attack_cell = attack_cell->getNeighbour(4);
        }
        else if (direction == "sw"){
            attack_cell = attack_cell->getNeighbour(5);
        }
        else if (direction == "so"){
            attack_cell = attack_cell->getNeighbour(6);
        }
        else if (direction == "se"){
            attack_cell = attack_cell->getNeighbour(7);
        }else{
	    throw("Unexpected direction for attack.");
	}

  if (attack_cell->getTextDisplay()->getPlayerClass() != "Wizard"){
      break;
  }
  if (!attack_cell->isGameBoard()){
      break;
  }
  if (attack_cell->hasEnemy()){
      break;
  }
	std::cout << "check has enemy" << std::endl;
    }

    return attack_cell;
}

void Player::playerAttack(std::string direction){
    Cell * attack_cell = NULL;
    int damage = 0;

    attack_cell = this->getAttackCell(direction);

    if (attack_cell->isOccupied() && attack_cell->hasEnemy()){
        Enemy* target_enemy = (Enemy*)(attack_cell->getContent());
        damage = this->attack(target_enemy);
        if (!target_enemy->isHostile()){
            target_enemy->setHostile();
        }
        // std::cout << "enemy health: " << target_enemy->getHealth() << std::endl; //DEBUG
        std::cout << "You attack the " << target_enemy->getEnemyType() << " with your " << attack_name << " for " << damage << " damage!" << std::endl;
        if (target_enemy->getHealth() == 0){
            std::cout << "The " << target_enemy->getEnemyType() << " has died." << std::endl;
        }
    }else{
        // std::cerr << "There is nothing there to attack!" << std::endl;
        throw("There is nothing there to attack!");
    }
}

Player::~Player(){}

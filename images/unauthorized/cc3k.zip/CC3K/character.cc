#include "character.h"

bool Character::enemyMobile = true;

Character::Character(){

}

int Character::getHealth() const{
  return this->HP;
}

int Character::getAttack() const{
  return this->ATK;
}

int Character::getDefence() const{
  return this->DEF;
}

int Character::getBaseAttack() const{
  return this->baseATK;
}

int Character::getBaseDefence() const{
  return this->baseDEF;
}

void Character::setHealth(int amt){
    this->HP = amt;
}

void Character::setAttack(int amt){
  this->ATK = amt;
}

void Character::setDefence(int amt){
  this->DEF = amt;
}

void Character::move(Cell * location){
  if(location != NULL && (enemyMobile == true || _display == '@')){
    this->_location->setOccupant(NULL);
    this->setCell(location);
    this->_location->setOccupant(this);
  }
}

int Character::attack(Character* target_character){
    int damage = std::ceil(this->getAttack()*(100.0-target_character->getDefence())/100.0);
    target_character->setHealth(fmax(target_character->getHealth() - damage,0));
    return damage;
}

void Character::setMobile(bool val){
  enemyMobile = val;
}

void Character::consumeRHPotion(){
  this->setHealth(fmin(this->maxHP, this->getHealth() + 30));
}

void Character::consumeBAPotion(){
  this->setAttack(this->getAttack() + 10);
}

void Character::consumeBDPotion(){
  this->setDefence(fmin(100.0,this->getDefence() + 10));
}

void Character::consumePHPotion(){
  this->setHealth(fmax(this->getHealth() - 15, 0));
}

void Character::consumeWAPotion(){
  this->setAttack(fmax(this->getAttack() - 5, 0));
}

void Character::consumeWDPotion(){
  this->setDefence(fmax(this->getDefence() - 5, 0));
}

void Character::pickUpPotion(Potion* potion){
  std::string potion_type = potion->pickUp();
  std::cout << "potion type: " << potion_type << std::endl;
  if(potion_type == "RH"){
    this->consumeRHPotion();
  }
  
  if(potion_type == "BA"){
    this->consumeBAPotion();
  }
  
  if(potion_type == "BD"){
    this->consumeBDPotion();
  }
  
  if(potion_type == "PH"){
    this->consumePHPotion();
  }
  
  if(potion_type == "WA"){
    this->consumeWAPotion();
  }
  
  if(potion_type == "WD"){
    this->consumeWDPotion();
  }
}

Character::~Character(){}

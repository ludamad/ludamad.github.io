#include "knight.h"

Knight::Knight(){
    maxHP = 100;
    baseATK = 50;
    baseDEF = 50;
    HP =  maxHP;
    ATK = baseATK;
    DEF = baseDEF;
    attack_name = "Sword of Segfault";
}

Knight::~Knight(){}

#include <iostream>
#include <string>
#include <vector>
#include "game.h"

extern int DUNGEONHEIGHT;
extern int DUNGEONWIDTH;

///////////////

Game::Game(char playerClass, std::string filename){

	display = new TextDisplay(playerClass);

    switch(playerClass){
        case 'k':
            player = new Knight();
        break;
        case 'w':
            player = new Wizard();
        break;
        case 's':
            player = new Samurai();
	    // hostile stuff
        break;
    }

    board = new Board(this, filename);

    if (this->display->getPlayerClass() == "Samurai"){
        Orc::setNeutral();
        Goblin::setNeutral();
        Gridbug::setNeutral();
        Dragon::setNeutral();    
    }
    
	turns = 1;
	dungeonFloor = 1;
	score = 0;
	stopwander = false;
	stopdeath = false;
}

Game::~Game(){
	delete display; // delete textdisplay

	delete board;
}

int Game::getFloor(){
	return dungeonFloor;
}

bool Game::onStairs(){
    if(player->getLocation()->isStairs()){
        return true;
    } else {
        return false;
    }
}

void Game::setFloor(int fl){
	dungeonFloor = fl;
}

void Game::nextFloor(){
    board->nextFloor();
    setFloor(dungeonFloor + 1);
    this->player->setAttack(this->player->getBaseAttack());
    this->player->setDefence(this->player->getBaseDefence());
}

void Game::nextTurn(){
    turns++;
}

Player* Game::getPlayer(){
    return player;
}

int Game::getScore(){
	return score;
}


Cell* Game::checkPotion(int row, int col){
	Cell * cell = board->returnCell(row, col);
	for(int i = 0; i < 8; i++){
		if(cell->getNeighbour(i)->isOccupied() &&
		   cell->getNeighbour(i)->hasPotion()){
			   return cell->getNeighbour(i);
		}
	}
	return NULL;
}

void Game::directEnemies(){
    Enemy * enemy = NULL;
    Cell * next_cell = NULL;

    while(!enemy_list.empty()){
        enemy = enemy_list.front();
        // std::cout << "Enemy Type: " << enemy->getEnemyType() << std::endl;
        if (enemy->getHealth() == 0){
            std::cout << enemy->getEnemyType() << std::endl;
            this->dropItem(enemy->getX(), enemy->getY(), enemy->getEnemyType());
            delete enemy;
            return;
        } else if (enemy->humanNearby() && enemy->isHostile()){
        	enemy->fullAttack(player);
	  	} else if(enemy->getEnemyType() == "Goblin" && this->checkPotion(enemy->getX(), enemy->getY())){
			Cell * potion_cell = this->checkPotion(enemy->getX(), enemy->getY());
			enemy->pickUpPotion((Potion*)potion_cell->getContent());
			potion_cell->emptyCell();
		} else if(!this->checkStopWander()){
          // std::cout << "about to move x: " << row << " y: " << col << std::endl; // DEBUG
          next_cell = enemy->randomEnemyMoveLocation();
          //std::cout << "out of random - enemy type: " << enemy->getEnemyType() << std::endl; // DEBUG
          enemy->move(next_cell);
        }
        // std::cout << "enemy health: " << enemy->getHealth() << std::endl; 
        enemy_list.pop();
    }
}

void Game::dropItem(int row, int col, std::string enemy_type){
    Item * item = NULL;
    int rand_potion = prng(6);
    std::string potion_type = " ";
    if (enemy_type == "Goblin" ||
        enemy_type == "Merchant" ||
        enemy_type == "Orc"){
        item = new Gold('P');
    }
    if (enemy_type == "Grid Bug"){
        switch(rand_potion){
            case 1:
                potion_type = "RH";
            break;
            case 2:
                potion_type = "BA";
            break;
            case 3:
                potion_type = "BD";
            break;
            case 4:
                potion_type = "PH";
            break;
            case 5:
                potion_type = "WA";
            break;
            case 6:
                potion_type = "WD";
            break;
            default:
                potion_type = "RH";
            break;
        }
        item = new Potion(potion_type);
    }
    board->returnCell(row, col)->setOccupant(item);
}

bool Game::checkGold(std::string dir){
	int x = this->player->getX();
    int y = this->player->getY();
    Cell * gold_cell = NULL;

    if (dir == "no"){
        x--;
    }
    if (dir == "so"){
        x++;
    }
    if (dir == "ea"){
        y++;
    }
    if (dir == "we"){
        y--;
    }
    if (dir == "ne"){
        y++;
        x--;
    }
    if (dir == "nw"){
        y--;
        x--;
    }
    if (dir == "se"){
        y++;
        x++;
    }
    if (dir == "sw"){
        y--;
        x++;
    }
	if (x >=0 && x <= DUNGEONHEIGHT && y >= 0 && y <= DUNGEONWIDTH){
        gold_cell = board->returnCell(x, y);
		if (gold_cell->isOccupied() && gold_cell->hasGold()){
	        return true;
		}
    }
		return false;
}

void Game::movePlayer(std::string dir){
    //pick up gold
	if(this->checkGold(dir)){
		playerUseItem(dir);
		return;
	}

    player->checkMove(dir);
}

void Game::moveEnemy(){

}

void Game::playerAttack(std::string direction){
  player->playerAttack(direction);
}

void Game::enemyAttack(){
  // something something automated attack
}

void Game::playerUseItem(std::string direction){
    int x = this->player->getX();
    int y = this->player->getY();
    Cell * item_cell = NULL;
    std::string item_name = " ";

    if (direction == "no"){
        x--;
    }

    if (direction == "so"){
        x++;
    }

    if (direction == "ea"){
        y++;
    }

    if (direction == "we"){
        y--;
    }

    if (direction == "ne"){
        y++;
        x--;
    }

    if (direction == "nw"){
        y--;
        x--;
    }

    if (direction == "se"){
        y++;
        x++;
    }

    if (direction == "sw"){
        y--;
        x++;
    }

    if (x >=0 && x <= 24 && y >= 0 && y <= 78){
        item_cell = board->returnCell(x, y);
    }else{
        throw("There is nothing there to use!");
    }

    if (item_cell->isOccupied() && item_cell->hasPotion()){
        Potion * p = (Potion*)(item_cell->getContent());
        item_name = p->getPotionName();
        this->player->pickUpPotion(p);
        std::cout << "You chug the " << item_name << " potion." << std::endl;
        item_cell->emptyCell();
    }else if (item_cell->isOccupied() &&item_cell->hasGold()){
        Gold * g = (Gold*)(item_cell->getContent());
        item_name = g->getGoldName();
        if(item_name == "Dragon Hoard" &&
           g->getLocation()->dragonNearby()){
            throw("It would be foolhardy to take the dragon's gold right now");
        }
        this->player->pickUpGold(g);
        std::cout << "You pick up the " << item_name << " worth ";
        if (item_name == "Gold Pile"){
            std::cout << "10GP." << std::endl;
        }else if (item_name == "Dragon Hoard"){
            std::cout << "50GP." << std::endl;
        }
        item_cell->emptyCell();
    }else{
        throw("There is nothing there to use!");
    }

}

void Game::updatePlayerStats(){
    this->display->notifyHP(this->player->getHealth());
    this->display->notifyATK(this->player->getAttack());
    this->display->notifyDEF(this->player->getDefence());
    this->display->notifyGP(this->player->getGP());
    this->display->notifyTurn(this->turns);
    this->display->notifyFloor(this->dungeonFloor);
}

void Game::regenerateHealth(){
    this->player->regenerateHealth();
}

void Game::print(){
	display->print();
}

TextDisplay* Game::getTextDisplay(){
    return display;
}

void Game::updateEnemyQueue(){
    while(!enemy_list.empty()){
        enemy_list.pop();
    }
    for (int row = 0; row < DUNGEONHEIGHT; row++){
        for (int col = 0; col < DUNGEONWIDTH; col++){
            if(board->returnCell(row, col)->isOccupied() && board->returnCell(row, col)->hasEnemy()){
                enemy_list.push((Enemy*)board->returnCell(row, col)->getContent());
            }
        }
    }
}

void Game::setStopWander(){
    stopwander = true;
    std::cout << "Enemy actions that would result in movement now do nothing instead." << std::endl;
}

void Game::setStopDeath(){
    stopdeath = true;
    std::cout << "Player death can no longer occur." << std::endl;
}

bool Game::checkStopWander(){
	return this->stopwander;
}

bool Game::checkStopDeath(){
	return this->stopdeath;
}

void Game::gameWin(){
    std::cout << "At long last, you have outmatched the Great Cavernous Chambers. Great things await you." << std::endl;
    std::cout << "You achieved a score of " << player->getGP() << "." << std::endl;
}

#include "gridbug.h"

bool Gridbug::hostile = true;

Gridbug::Gridbug(){
	_display = 'X';
  maxHP = 50;
  baseATK = 20;
  baseDEF = 10;
	HP = maxHP;
  ATK = baseATK;
  DEF = baseDEF;
//    hostile = true;
}

Gridbug::~Gridbug(){
}

bool Gridbug::isHostile(){
    return this->hostile;
}

void Gridbug::setHostile(){
    hostile = true;
    std::cout << "This is an act of war to every Grid Bug!" << std::endl;
}

void Gridbug::setNeutral(){
    hostile = false;
}

Cell * Gridbug::randomEnemyMoveLocation(){ // only chooses from no, so, we, ea squares
   int possibleMoves = 4;
   Cell* freesquares[4];
   int freesq = -1;
   int chosen = 0;
   for(int i = 0; i < possibleMoves; i++){
     int j;
     if (i == 0) {j = 1;}
     else if (i == 1) {j = 3;}
     else if (i == 2) {j = 4;}
     else if (i == 3) {j = 6;}
     
     if (this->_location->getNeighbour(j)->enemyWalkable()){
           freesq++;
           freesquares[freesq] = this->_location->getNeighbour(j);
     }
   }
   if(freesq >= 0){
       if(freesq != 0){
       	 chosen = prng(freesq);
       }
       // std::cout << "x: " << freesquares[chosen]->getX() << " y: " << freesquares[chosen]->getY() << " chosen: " << chosen << std::endl; // DEBUG
       return freesquares[chosen];
    } else {
         return NULL;
    }
}

bool Gridbug::humanNearby(){ // looks for player only from no, so, we, ea squares
    if(this->_location->getNeighbour(1)->isOccupied() &&
       this->_location->getNeighbour(1)->getContent()->getDisplay() == '@'){
         return true;
    }
    if(this->_location->getNeighbour(3)->isOccupied() &&
       this->_location->getNeighbour(3)->getContent()->getDisplay() == '@'){
          return true;
    }
    if(this->_location->getNeighbour(4)->isOccupied() &&
       this->_location->getNeighbour(4)->getContent()->getDisplay() == '@'){
         return true;
    }
    if(this->_location->getNeighbour(6)->isOccupied() &&
       this->_location->getNeighbour(6)->getContent()->getDisplay() == '@'){
          return true;
    }
    return false;
}

#include "gameObject.h"
//#include "cell.h"

gameObject::gameObject(){
  //TODO:
}

int gameObject::getX() const{
  return this->_location->getX();
}  // getters

int gameObject::getY() const{
  return this->_location->getY();
}

  //called every turn //TODO: figure out how to use

void gameObject::setCell(Cell * cell){
  this->_location = cell;
}

char gameObject::getDisplay(){
	return this->_display;
}

Cell * gameObject::getLocation(){
	return this->_location;
}

gameObject::~gameObject(){}

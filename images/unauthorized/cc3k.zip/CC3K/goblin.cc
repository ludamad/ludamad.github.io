#include "goblin.h"

bool Goblin::hostile = true;

Goblin::Goblin(){
	_display = 'g';
	maxHP = 75;
	baseATK = 30;
	baseDEF = 20;
	HP = maxHP;
    ATK = baseATK;
    DEF = baseDEF;
}

Goblin::~Goblin(){
}

bool Goblin::isHostile(){
    return this->hostile;
}

void Goblin::setHostile(){
    hostile = true;
    std::cout << "This is an act of war to every Goblin!" << std::endl;
}

void Goblin::setNeutral(){
    hostile = false;
}

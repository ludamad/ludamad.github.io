#include "dragon.h"

bool Dragon::hostile = true;

Dragon::Dragon(){
	_display = 'D';
    maxHP = 150;
    baseATK = 50;
    baseDEF = 10;
	HP = maxHP;
    ATK = baseATK;
    DEF = baseDEF;
    //hostile = true;
}

Dragon::~Dragon(){
}

bool Dragon::isHostile(){
    return this->hostile;
}

void Dragon::setHostile(){
    hostile = true;
    std::cout << "This is an act of war to every Dragon!" << std::endl;
}

void Dragon::setNeutral(){
    hostile = false;
}

Cell * Dragon::randomEnemyMoveLocation(){
    return NULL;
}

#ifndef KNIGHT_H
#define KNIGHT_H

#include "player.h"

class Knight : public Player {
public:
	Knight();
	~Knight();
};

#endif

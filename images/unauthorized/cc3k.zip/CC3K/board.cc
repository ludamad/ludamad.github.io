#include <iostream>
#include <fstream>

#include "board.h"

extern int DUNGEONHEIGHT;
extern int DUNGEONWIDTH;

Board::Board(Game * controller, std::string file){
	game = controller;
	display = controller->getTextDisplay();
    filename = file;

    if (filename != ""){
        ifs.open(filename.c_str());
        ifs >> std::noskipws;
    }

	grid = new Cell*[25]; // initialize grid
    for(int x = 0; x < DUNGEONHEIGHT; x++){
        grid[x] = new Cell[79];
    }

    grid[0][0].addDisplay(display); // static

    for(int row = 0; row < DUNGEONHEIGHT; row++){
		for(int col = 0; col < DUNGEONWIDTH; col++){
			grid[row][col].setX(row); // initialize row, col
		    grid[row][col].setY(col);


		    if(row != 0){ // initialize neighbours
		    	if(col != 0){
              	  grid[row][col].addNeighbour(&grid[row-1][col-1]); // add NW neighbour
          	    }
          	    grid[row][col].addNeighbour(&grid[row-1][col]); // add NO neighbour
            	if(col != DUNGEONWIDTH - 1){
	                grid[row][col].addNeighbour(&grid[row-1][col+1]); // add NE neighbour
    	        }
            }
            if(col != 0){
                grid[row][col].addNeighbour(&grid[row][col-1]); // add WE neighbour
            }
            if(col != DUNGEONWIDTH - 1){
                grid[row][col].addNeighbour(&grid[row][col+1]); // add EA neighbour
            }
            if(row != DUNGEONHEIGHT - 1){ // initialize neighbours
		    	if(col != 0){
              	  grid[row][col].addNeighbour(&grid[row+1][col-1]); // add SW neighbour
          	    }
          	    grid[row][col].addNeighbour(&grid[row+1][col]); // add SO neighbour
            	if(col != DUNGEONWIDTH - 1){
	                grid[row][col].addNeighbour(&grid[row+1][col+1]); // add SE neighbour
    	        }
            }
        }
	}

	constructRoomA();
	constructRoomB();
	constructRoomC();
	constructRoomD();
	constructRoomE();
    constructDoor();
	constructPassage();
	constructBorder();

	// std::cout << "file: " << filename << std::endl; // DEBUG

    if(filename == ""){
        // std::cout << "random floor" << std::endl; // DEBUG
        spawnPlayerandStairs();
        spawnPotions();
        spawnGold();
        spawnEnemies();
    } else {
        // std::cout << "custom floor" << std::endl; // DEBUG
        customFloor();
    }
}


Board::~Board(){
	for(int i = 0; i < DUNGEONHEIGHT; i++){ // delete grid
        delete [] grid[i];
	}
    delete [] grid;
}

void Board::customFloor(){
    char objchar;
    for(int row = 0; row < DUNGEONHEIGHT; row++){
        for(int col = 0; col < DUNGEONWIDTH; col++){
            objchar = ifs.get();
            while (objchar == '\n' || objchar == '\r') {
                objchar = ifs.get();
            }
 //           std::cout << "row: " << row << " col: " << col << " char: " << objchar << std::endl; // DEBUG
            gameObject * obj;
            if (objchar == 'X'){
                obj = new Gridbug();
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == 'g'){
                obj = new Goblin();
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == 'M'){
                obj = new Merchant();
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == 'O'){
                obj = new Orc();
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == 'D'){
                obj = new Dragon();
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '0'){
                obj = new Potion("RH");
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '1'){
                obj = new Potion("BA");
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '2'){
                obj = new Potion("BD");
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '3'){
                obj = new Potion("PH");
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '4'){
                obj = new Potion("WA");
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '5'){
                obj = new Potion("WD");
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '6'){
                obj = new Gold('P');
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '7'){
                obj = new Gold('H');
                obj->setCell(&grid[row][col]);
                this->setgameObject(obj->getX(), obj->getY(), obj);
            }
            if (objchar == '@'){
                Player* player = game->getPlayer();
                player->setCell(&grid[row][col]);
                this->setgameObject(player->getX(), player->getY(), player);
            }
            if (objchar == '>'){
                grid[row][col].setCharDisp('>');
            }
        }
    }
}

void Board::clearBoard(){
    Cell * playercell = game->getPlayer()->getLocation();
    playercell->setCharDisp('.'); // restores floor type to normal
    playercell->setOccupant(NULL);
    game->getPlayer()->setCell(NULL); // prevents player from being deleted w/floor objects

    for(int i = 0; i < DUNGEONHEIGHT; i++){
        for(int j = 0; j < DUNGEONWIDTH; j++){
            grid[i][j].clearOccupant();  // delete any gameobject
        }
    }
}

void Board::nextFloor(){
    clearBoard();
    if(filename == ""){
        // std::cout << "random floor" << std::endl; // DEBUG
        spawnPlayerandStairs();
        spawnPotions();
        spawnGold();
        spawnEnemies();
    } else {
        // std::cout << "new custom floor" << std::endl; // DEBUG
        customFloor();
    }
}

void Board::setgameObject(int x, int y, gameObject * piece){
	grid[x][y].setOccupant(piece);
}

Cell* Board::returnCell(int x, int y){
	return &grid[x][y];
}

void Board::constructRoomA(){
	for(int row = 4; row < 8; row++){
		for(int col = 4; col < 30; col++){
			grid[row-1][col-1].setCharDisp('.');
		}
	}

	for(int col = 4; col < 30; col++){
		grid[3-1][col-1].setCharDisp('-');
		grid[8-1][col-1].setCharDisp('-');
	}

	for(int row = 3; row < 9; row++){
		grid[row-1][3-1].setCharDisp('|');
		grid[row-1][30-1].setCharDisp('|');
	}
}

void Board::constructRoomB(){
    for(int col = 40; col < 63; col++){
        grid[4-1][col-1].setCharDisp('.');
        grid[5-1][col-1].setCharDisp('.');
    }
    for(int col = 40; col < 71; col++){
        grid[6-1][col-1].setCharDisp('.');
    }
    for(int col = 40; col < 74; col++){
        grid[7-1][col-1].setCharDisp('.');
    }
    for(int row = 8; row < 14; row++){
        for(int col = 62; col < 77; col++){
            grid[row-1][col-1].setCharDisp('.');
        }
    }

    for(int col = 40; col < 63; col++){
        grid[3-1][col-1].setCharDisp('-');
    }
    for(int col = 64; col < 71; col++){
        grid[5-1][col-1].setCharDisp('-');
    }
    for(int col = 72; col < 74; col++){
        grid[6-1][col-1].setCharDisp('-');
    }
    for(int col = 75; col < 77; col++){
        grid[7-1][col-1].setCharDisp('-');
    }
    for(int col = 40; col < 61; col++){
        grid[8-1][col-1].setCharDisp('-');
    }
    for(int col = 62; col < 77; col++){
        grid[14-1][col-1].setCharDisp('-');
    }

    for(int row = 3; row < 9; row++){
        grid[row-1][39-1].setCharDisp('|');
    }
    for(int row = 8; row < 15; row++){
        grid[row-1][61-1].setCharDisp('|');
    }
    for(int row = 3; row < 6; row++){
        grid[row-1][63-1].setCharDisp('|');
    }
    for(int row = 5; row < 7; row++){
        grid[row-1][71-1].setCharDisp('|');
    }
    for(int row = 6; row < 8; row++){
        grid[row-1][74-1].setCharDisp('|');
    }
    for(int row = 7; row < 15; row++){
        grid[row-1][77-1].setCharDisp('|');
    }
}

void Board::constructRoomC(){
	for(int row = 11; row < 14; row++){
		for(int col = 39; col < 51; col++){
			grid[row-1][col-1].setCharDisp('.');
		}
	}

	for(int col = 39; col < 51; col++){
		grid[10-1][col-1].setCharDisp('-');
		grid[14-1][col-1].setCharDisp('-');
	}

	for(int row = 10; row < 15; row++){
		grid[row-1][38-1].setCharDisp('|');
		grid[row-1][51-1].setCharDisp('|');
	}
}

void Board::constructRoomD(){
	for(int row = 16; row < 23; row++){
		for(int col = 5; col < 26; col++){
			grid[row-1][col-1].setCharDisp('.');
		}
	}

	for(int col = 5; col < 26; col++){
		grid[15-1][col-1].setCharDisp('-');
		grid[23-1][col-1].setCharDisp('-');
	}

	for(int row = 15; row < 24; row++){
		grid[row-1][4-1].setCharDisp('|');
		grid[row-1][26-1].setCharDisp('|');
	}
}

void Board::constructRoomE(){
    for(int row = 17; row < 20; row++){
        for(int col = 66; col < 77; col++){
            grid[row-1][col-1].setCharDisp('.');
        }
    }
    for(int row = 20; row < 23; row++){
        for(int col = 38; col < 77; col++){
            grid[row-1][col-1].setCharDisp('.');
        }
    }

    for(int col = 66; col < 77; col++){
        grid[16-1][col-1].setCharDisp('-');
    }
    for(int col = 38; col < 65; col++){
        grid[19-1][col-1].setCharDisp('-');
    }
    for(int col = 38; col < 77; col++){
        grid[23-1][col-1].setCharDisp('-');
    }

    for(int row = 19; row < 24; row++){
        grid[row-1][37-1].setCharDisp('|');
    }
    for(int row = 16; row < 20; row++){
        grid[row-1][65-1].setCharDisp('|');
    }
    for(int row = 16; row < 24; row++){
        grid[row-1][77-1].setCharDisp('|');
    }
}

void Board::constructDoor(){
    grid[5-1][30-1].setCharDisp('+');
    grid[5-1][39-1].setCharDisp('+');
    grid[8-1][14-1].setCharDisp('+');
    grid[8-1][44-1].setCharDisp('+');
    grid[10-1][44-1].setCharDisp('+');
    grid[12-1][61-1].setCharDisp('+');
    grid[14-1][44-1].setCharDisp('+');
    grid[14-1][70-1].setCharDisp('+');
    grid[15-1][14-1].setCharDisp('+');
    grid[16-1][70-1].setCharDisp('+');
    grid[19-1][44-1].setCharDisp('+');
    grid[21-1][26-1].setCharDisp('+');
    grid[21-1][37-1].setCharDisp('+');

}

void Board::constructPassage(){
    for(int col = 31; col < 39; col++){
        grid[5-1][col-1].setCharDisp('#');
    }
    for(int col = 32; col < 45; col++){
        grid[9-1][col-1].setCharDisp('#');
    }
    for(int col = 14; col < 33; col++){
        grid[12-1][col-1].setCharDisp('#');
    }
    for(int col = 55; col < 61; col++){
        grid[12-1][col-1].setCharDisp('#');
    }
    for(int col = 32; col < 56; col++){
        grid[17-1][col-1].setCharDisp('#');
    }
    for(int col = 27; col < 37; col++){
        grid[21-1][col-1].setCharDisp('#');
    }

    for(int row = 9; row < 15; row++){
        grid[row-1][14-1].setCharDisp('#');
    }
    for(int row = 9; row < 22; row++){
        grid[row-1][32-1].setCharDisp('#');
    }
    for(int row = 5; row < 10; row++){
        grid[row-1][34-1].setCharDisp('#');
    }
    for(int row = 15; row < 19; row++){
        grid[row-1][44-1].setCharDisp('#');
    }
    for(int row = 12; row < 18; row++){
        grid[row-1][55-1].setCharDisp('#');
    }

    grid[14][69].setCharDisp('#');
}

void Board::constructBorder(){
	for(int col = 2; col < 79; col++){
		grid[1-1][col-1].setCharDisp('-');
		grid[25-1][col-1].setCharDisp('-');
	}

	for(int row = 1; row < 26; row++){
		grid[row-1][1-1].setCharDisp('|');
		grid[row-1][79-1].setCharDisp('|');
	}
}

Cell* Board::randomCellRoomA(){
    int cellnum = prng(26 * 4 - 1);
    int rownum = (cellnum / 26) + 3;
    int colnum = (cellnum % 26) + 3;
    return &grid[rownum][colnum];
}

Cell* Board::randomCellRoomB(){
    int cellnum = prng(200);
    int rownum;
    int colnum;
    if (cellnum < 46){
        rownum = (cellnum / 23) + 3;
        colnum = (cellnum % 23) + 39;
    } else if (cellnum < 77) {
        rownum = 5;
        colnum = (cellnum - 7);
    } else if (cellnum < 111) {
        rownum = 6;
        colnum = (cellnum - 38);
    } else {
        rownum = ((cellnum - 111) / 15) + 7;
        colnum = ((cellnum - 111) % 15) + 61;
    }
    return &grid[rownum][colnum];
}

Cell* Board::randomCellRoomC(){
    int cellnum = prng(12 * 3 - 1);
    int rownum = (cellnum / 12) + 10;
    int colnum = (cellnum % 12) + 38;
    return &grid[rownum][colnum];
}

Cell* Board::randomCellRoomD(){
    int cellnum = prng(21 * 7 - 1);
    int rownum = (cellnum / 21) + 15;
    int colnum = (cellnum % 21) + 4;
    return &grid[rownum][colnum];
}

Cell* Board::randomCellRoomE(){
    int cellnum = prng(149);
    int rownum;
    int colnum;
    if (cellnum < 33){
        rownum = (cellnum / 11) + 16;
        colnum = (cellnum % 11) + 65;
    } else {
        rownum = ((cellnum - 33) / 39) + 19;
        colnum = ((cellnum - 33) % 39) + 37;
    }

    return &grid[rownum][colnum];
}

Enemy * Board::enemyGenerator(){
    int random = prng(5);
    Enemy * randomEnemy;
    switch(random){
        case 0:
          randomEnemy = new Gridbug();
          break;
        case 1:
          randomEnemy = new Gridbug();
          break;
        case 2:
          randomEnemy = new Goblin();
          break;
        case 3:
          randomEnemy = new Goblin();
          break;
        case 4:
          randomEnemy = new Orc();
          break;
        case 5:
          randomEnemy = new Merchant();
          break;
    }
    return randomEnemy;
}

Gold* Board::goldGenerator(){
    int random = prng(7);
    Gold * randomGold;
    switch(random){
        case 0:
          randomGold = new Gold('P');
          break;
        case 1:
          randomGold = new Gold('P');
          break;
        case 2:
          randomGold = new Gold('P');
          break;
        case 3:
          randomGold = new Gold('P');
          break;
        case 4:
          randomGold = new Gold('P');
          break;
        case 5:
          randomGold = new Gold('P');
          break;
        case 6:
          randomGold = new Gold('P');
          break;
        case 7:
          randomGold = new Gold('H');
          break;
    }
    return randomGold;
}

Potion* Board::potionGenerator(){
    int random = prng(5);
    Potion * randomPotion;
    switch(random){
        case 0:
          randomPotion = new Potion("RH");
          break;
        case 1:
          randomPotion = new Potion("BA");
          break;
        case 2:
          randomPotion = new Potion("BD");
          break;
        case 3:
          randomPotion = new Potion("PH");
          break;
        case 4:
          randomPotion = new Potion("WA");
          break;
        case 5:
          randomPotion = new Potion("WD");
          break;
    }

    return randomPotion;
}


void Board::spawnPlayerandStairs(){
    int playerRoomNum = prng(4);
    Cell * playerRoom;
    switch(playerRoomNum){
        case 0:
          playerRoom = randomCellRoomA();
          break;
        case 1:
          playerRoom = randomCellRoomB();
          break;
        case 2:
          playerRoom = randomCellRoomC();
          break;
        case 3:
          playerRoom = randomCellRoomD();
          break;
        case 4:
          playerRoom = randomCellRoomE();
          break;
    }
    Player* player = game->getPlayer();
    player->setCell(playerRoom);
    this->setgameObject(player->getX(), player->getY(), player);

    int stairsRoomNum = prng(3);
    Cell * stairsRoom;
    if (stairsRoomNum >= playerRoomNum) {
        stairsRoomNum += 1;
    }
    switch(stairsRoomNum){
        case 0:
          stairsRoom = randomCellRoomA();
          break;
        case 1:
          stairsRoom = randomCellRoomB();
          break;
        case 2:
          stairsRoom = randomCellRoomC();
          break;
        case 3:
          stairsRoom = randomCellRoomD();
          break;
        case 4:
          stairsRoom = randomCellRoomE();
          break;
    }
    stairsRoom->setCharDisp('>');
}

void Board::spawnPotions(){
    int NUM_POTIONS = 10;
    for(int i = 0; i < NUM_POTIONS; i++){
       // Potion * drink = potionGenerator();
        while(true){
            int RoomNum = prng(4);
            Cell * room;

            switch(RoomNum){
              case 0:
                room = randomCellRoomA();
                break;
              case 1:
                room = randomCellRoomB();
                break;
              case 2:
                room = randomCellRoomC();
                break;
              case 3:
                room = randomCellRoomD();
                break;
              case 4:
                room = randomCellRoomE();
                break;
            }
            if(!room->isOccupied()){
                Potion * drink = potionGenerator();
                drink->setCell(room);
                this->setgameObject(drink->getX(), drink->getY(), drink);
                break;
            }
        }
    }
}

void Board::spawnGold(){
    int NUM_GOLD = 10;
    for(int i = 0; i < NUM_GOLD; i++){
//        Gold * dungeongold = goldGenerator();

        while(true){
            int RoomNum = prng(4);
            Cell * room;

            switch(RoomNum){
              case 0:
                room = randomCellRoomA();
                break;
              case 1:
                room = randomCellRoomB();
                break;
              case 2:
                room = randomCellRoomC();
                break;
              case 3:
                room = randomCellRoomD();
                break;
              case 4:
                room = randomCellRoomE();
                break;
            }
            if(!room->isOccupied()){
                Gold * dungeongold = goldGenerator();
                dungeongold->setCell(room);
                this->setgameObject(dungeongold->getX(), dungeongold->getY(), dungeongold);
             //   std::cout << "setting gold " << i << " at x: " << dungeongold->getX() << " y: " << dungeongold->getY() << std::endl; // DEBUG
                if (dungeongold->getGoldName() == "Dragon Hoard"){
                    while(true){
                        int dragonCell = prng(7);
                        if(room->getNeighbour(dragonCell)->enemyWalkable()){
                            Dragon * drgn = new Dragon();
                            drgn->setCell(room->getNeighbour(dragonCell));
                            this->setgameObject(drgn->getX(), drgn->getY(), drgn);
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
}

void Board::spawnEnemies(){
    int NUM_ENEMIES = 20;
    for(int i = 0; i < NUM_ENEMIES; i++){
        while(true){
        //    Enemy * creature = enemyGenerator();

            int RoomNum = prng(4);
            Cell * room;

            switch(RoomNum){
              case 0:
                room = randomCellRoomA();
                break;
              case 1:
                room = randomCellRoomB();
                break;
              case 2:
                room = randomCellRoomC();
                break;
              case 3:
                room = randomCellRoomD();
                break;
              case 4:
                room = randomCellRoomE();
                break;
            }
            if(!room->isOccupied()){
                Enemy * creature = enemyGenerator();
                creature->setCell(room);
                this->setgameObject(creature->getX(), creature->getY(), creature);
                break;
            }
        }
    }
}

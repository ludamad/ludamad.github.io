#ifndef ENEMY_H
#define ENEMY_H
#include "character.h"
#include <string>

class Enemy : public Character {

public:
	virtual bool isHostile() = 0;
	virtual void setHostile() = 0;
	std::string getEnemyType();
	virtual bool humanNearby();
	void fullAttack(Character * target);
	virtual Cell * randomEnemyMoveLocation();
	Enemy();
	virtual ~Enemy();
};

#endif

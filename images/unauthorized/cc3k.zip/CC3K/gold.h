#ifndef GOLD_H
#define GOLD_H

#include "item.h"
#include <string>

class Gold : public Item {
	char type; //'P' for pile, 'H' for Hoard
	public:
    	char pickUp();
    	Gold(char type);
    	std::string getGoldName();
    	~Gold();
};

#endif

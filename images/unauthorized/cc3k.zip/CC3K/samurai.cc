#include "samurai.h"

Samurai::Samurai(){
	maxHP = 80;
	baseATK = 50;
	baseDEF = 15;
	HP =  maxHP;
    ATK = baseATK;
    DEF = baseDEF;
    attack_name = "Memory Corruption Katana";
}

Samurai::~Samurai(){}

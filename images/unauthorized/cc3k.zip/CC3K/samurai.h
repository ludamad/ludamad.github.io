#ifndef SAMURAI_H
#define SAMURAI_H

#include "player.h"

class Samurai : public Player {
public:
	Samurai();
	~Samurai();
};

#endif

#ifndef PLAYER_H
#define PLAYER_H
#include "character.h"
#include "enemy.h"
#include <string>


class Player : public Character {
	int gold = 0;
	void takeGoldPile();
	void takeDragonHoard();
	Cell* getAttackCell(std::string dir);

protected:
	std::string attack_name;

public:
	void pickUpGold(Gold * gold);
	void regenerateHealth();
    int getGP();
	void checkMove(std::string dir);
	virtual void playerAttack(std::string dir);
	Player();
	~Player();
};

#endif

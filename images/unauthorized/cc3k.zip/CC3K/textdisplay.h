#ifndef __TEXTDISPLAY_H__
#define __TEXTDISPLAY_H__

#include <string>

class TextDisplay {
	char **theDisplay;
	std::string playerClass;
	int HP;
	int MaxHP;
	int ATK;
	int DEF;
	int GP;
	int turn;
	int flr;

public:
	TextDisplay(char cl);
	~TextDisplay();
	void notifyGameBoard(int r, int c, char ch);
	void notifyHP(int stat);
	void notifyDEF(int stat);
	void notifyATK(int stat);
	void notifyGP(int stat);
	void notifyTurn(int t);
	void notifyFloor(int f);
	void print();
	char getDisplay(int x, int y);
	std::string getPlayerClass();
};

#endif

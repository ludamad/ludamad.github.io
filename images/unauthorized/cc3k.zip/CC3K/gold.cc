#include "gold.h"

Gold::Gold(char type){
	if (type == 'P' || type == 'H'){
		this->type = type;
		_display = '$';
	}else{
		delete this;
	}
}

char Gold::pickUp(){
	return this->type;
}

std::string Gold::getGoldName(){
	if (type == 'P'){
		return "Gold Pile";
	}
	if (type == 'H'){
		return "Dragon Hoard";
	}
	return " ";
}

Gold::~Gold(){}
#include "merchant.h"

bool Merchant::hostile = false;

Merchant::Merchant(){
	_display = 'M';
	HP = maxHP;
    ATK = baseATK;
    DEF = baseDEF;
//    hostile = false;
}

Merchant::~Merchant(){}

bool Merchant::isHostile(){
    return this->hostile;
}

void Merchant::setHostile(){
    hostile = true;
    std::cout << "This is an act of war to every Merchant!" << std::endl;
}

void Merchant::setNeutral(){
    hostile = false;
}


#ifndef CELL_H
#define CELL_H

#include "textdisplay.h"
//#include "knight.h"
#include "gameObject.h"
#include "PRNG.h"

extern PRNG prng;
// forward declaration because mutual reference
 class gameObject;

class Cell {
    int _x, _y;
    char _display;

    gameObject* _contents;

    static TextDisplay* txtdisplay;
    int numNeighbours;
    Cell* neighbours[8];

    public:
        Cell(int x, int y);
        Cell();  // Default constructor

        int getX() const;
        int getY() const;
        void setX(int x);
        void setY(int y);
        void setCharDisp(char disp);

        void setOccupant(gameObject* gobj);
        void clearOccupant();
        bool isOccupied();
        void setCoords(int row, int col);
        void addNeighbour(Cell* neighbour);
        static void addDisplay(TextDisplay* disp);
        void emptyCell();
        gameObject* getContent();
        Cell * getNeighbour(int x);
        bool dragonNearby();
        Cell * potionNearby();
        bool hasEnemy();
        bool hasPotion();
        bool hasGold();
        bool playerWalkable();
        bool enemyWalkable();
	bool isGameBoard();
        bool isStairs();
	TextDisplay* getTextDisplay();
        ~Cell();
};

#endif

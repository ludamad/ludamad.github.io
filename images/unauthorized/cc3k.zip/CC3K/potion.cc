#include "potion.h"

Potion::Potion(std::string type){
  this->type = type;
  _display = '!';
}

std::string Potion::pickUp(){
  return this->type;
}

std::string Potion::getPotionName(){
	std::string potion_type = this->type;
	  if(potion_type == "RH"){
	    return "Restore Health";
	  }
	  
	  if(potion_type == "BA"){
	    return "Boost Attack";
	  }
	  
	  if(potion_type == "BD"){
	    return "Boost Defence";
	  }
	  
	  if(potion_type == "PH"){
	    return "Poison Health";
	  }
	  
	  if(potion_type == "WA"){
	    return "Wound Attack";
	  }
	  
	  if(potion_type == "WD"){
	    return "Wound Defence";
	  }

	  return " ";
}

Potion::~Potion(){}



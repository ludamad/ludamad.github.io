#ifndef POTION_H
#define POTION_H

#include "item.h"
#include <string>

class Potion : public Item {
    std::string type;
    //
    public:
      std::string pickUp(); //return type of potion and delete potion
      ~Potion();
      Potion(std::string type);
      std::string getPotionName();
};
#endif
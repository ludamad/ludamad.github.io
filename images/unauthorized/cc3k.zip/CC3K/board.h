#ifndef BOARD_H
#define BOARD_H

#include <string>
#include <fstream>

#include "potion.h"
#include "gold.h"

#include "knight.h"
#include "wizard.h"
#include "samurai.h"

#include "goblin.h"
#include "gridbug.h"
#include "merchant.h"
#include "dragon.h"
#include "orc.h"

#include "game.h"
#include "cell.h"
#include "textdisplay.h"

#include "PRNG.h"

class Game;

extern PRNG prng;

class Board{
	Cell** grid; 
	TextDisplay* display;
	Game* game;
    std::string filename;
    std::ifstream ifs;

public:

	Board(Game * controller, std::string file);
	~Board();

	void customFloor();
    void clearBoard();
    void nextFloor();
	void setgameObject(int x, int y, gameObject * piece);
	Cell* returnCell(int x, int y);

	void constructRoomA();
	void constructRoomB();
	void constructRoomC();
	void constructRoomD();
	void constructRoomE();
	void constructDoor();
    void constructPassage();
	void constructBorder();

	Cell* randomCellRoomA();
	Cell* randomCellRoomB();
	Cell* randomCellRoomC();
	Cell* randomCellRoomD();
	Cell* randomCellRoomE();

	Enemy * enemyGenerator();
    Gold * goldGenerator();
    Potion * potionGenerator();
    void spawnPlayerandStairs();
    void spawnPotions();
    void spawnGold();
    void spawnEnemies();
};


#endif

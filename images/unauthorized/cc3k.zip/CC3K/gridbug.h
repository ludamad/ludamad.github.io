#ifndef GRIDBUG_H
#define GRIDBUG_H

#include "enemy.h"

class Gridbug : public Enemy {
    static bool hostile;
public:
	Gridbug();
	~Gridbug();
    bool isHostile();
    void setHostile();
    static void setNeutral();
    Cell * randomEnemyMoveLocation();
    bool humanNearby();
};

#endif

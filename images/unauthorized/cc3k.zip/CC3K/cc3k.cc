#include <iostream>
#include <sstream>
#include <string>
#include <csignal>
#include <unistd.h>

#include "potion.h"
#include "gold.h"

#include "knight.h"
#include "wizard.h"
#include "samurai.h"

#include "goblin.h"
#include "gridbug.h"
#include "merchant.h"
#include "dragon.h"
#include "orc.h"

#include "board.h"
#include "game.h"
#include "cell.h"

#include "PRNG.h"

PRNG prng(getpid());


bool isDirection(std::string input){
	return (input == "no" ||
			input == "so" ||
			input == "ea" ||
			input == "we" ||
			input == "ne" ||
			input == "nw" ||
			input == "se" ||
			input == "sw");
}

bool isAttack(std::string input){
	return input == "a";
}

bool isUseItem(std::string input){
	return input == "u";
}

bool isRestart(std::string input){
	return input == "r";
}

bool isQuit(std::string input){
	return input == "q";
}

void signalHandler(int signalnum){ //handles a ctrl-C event
	if (signalnum == 2){
		std::cout << "You have chosen to exit. At least you tried." << std::endl;
        exit(0);
	}
}

int main(int argc, char *argv[]){

	uint32_t seed;
	std::string filename = "";
	std::string user_input = "";
	bool gameExitFlag = false;
	std::stringstream ss;
	std::string direction;
	std::string player_class_string;
	std::signal(SIGINT, signalHandler); //initialize signaler
	char player_class = ' ';
	switch(argc){
		case 1:
		break;
		case 2:
			ss << argv[1];
			if (ss >> seed){
                // std::cout << "seed" << std::endl; // DEBUG
				prng.seed(seed);
			} else {
                seed = 0;
				filename = ss.str();
                std::cout << "Loading board from '" << filename << "'." << std::endl;
			}
		break;
		case 3:
			ss << argv[1];
			if (ss >> seed){
                // std::cout << "seed: " << seed << std::endl; // DEBUG
				prng.seed(seed);
                ss.str(argv[2]); // feeds in next arg
				//ss << argv[2];
				filename = ss.str();
                std::cout << "Loading board from '" << filename << "'." << std::endl;
			}else {
				filename = ss.str();
                std::cout << "Loading board from '" << filename << "'." << std::endl;
                std::stringstream newss;
                newss << argv[2]; // feeds in next arg
				//ss << argv[2];
				if (newss >> seed){
                    // std::cout << "seed: " << seed << std::endl; // DEBUG
					prng.seed(seed);
				}else{
					std::cerr << "seed not a number, usage error message" << std::endl;
				}
			}
		break;
		default:
			std::cerr << "usage error message" << std::endl;
		break;
	}

	//create game
	while(!gameExitFlag){
		std::cout << "Welcome to ChamberCrawler3000!\nWhat would you like to play as today?\nw) Wizard\nk) Knight\ns) Samurai" << std::endl;
		while (true){
			std::cin >> user_input;
			if(std::cin.eof()){
				exit(0);
			}
			if (user_input == "w"){
				player_class = 'w';
				player_class_string = "Wizard";
				break;
				//std::cerr << "right now we only have knight. press k for knight." << std::endl; // temp
			}else if (user_input == "k"){
				player_class = 'k';
				player_class_string = "Knight";
				break;
			}else if (user_input == "s"){
				player_class = 's';
				player_class_string = "Samurai";
				break;
				//std::cerr << "right now we only have knight. press k for knight." << std::endl; // temp
			}else{
				std::cerr << "Did not recognize input." << std::endl;
			}
		}

	    // std::cout << "fname: " << filename << std::endl; // DEBUG

		Game* currentgame = new Game(player_class, filename);
		std::cerr << "You have chosen to play as a " << player_class_string << ". Good luck." << std::endl;
		currentgame->print();

	    while(true){
			//check death
			if (currentgame->getPlayer()->getHealth() == 0 &&
				!currentgame->checkStopDeath()){
				std::cout << "You have been bested by the Great Cavernous Chambers. Good luck next time!" << std::endl;
				std::cout << "You achieved a score of " << currentgame->getScore() << "." << std::endl;
				std::cout << "Play again? (y/n)" << std::endl;
				while (true){
					std::cin >> user_input;
					if(std::cin.eof()){
						break;
					}
					if (user_input == "y"){
						break;
					}else if (user_input == "n"){
						std::cout << "You have chosen to exit. At least you tried." << std::endl;
						gameExitFlag = true;
						break;
					}else {
						std::cerr << "Did not recognize input." << std::endl;
					}
				}
				break;
			}

			try{
				std::cin >> user_input;
				if (!std::cin.good()){
					std::cout << "You have chosen to exit. At least you tried." << std::endl;
					gameExitFlag = true;
					break;
				}
				if (isDirection(user_input)){
			//		std::cout << "move called" << std::endl; // DEBUG
					direction = user_input;
					currentgame->movePlayer(direction);

					//TODO:validate move, move player
				}else if(isAttack(user_input)){
					// std::cout << "attack called" << std::endl; // DEBUG
					std::cin >> direction;
					currentgame->playerAttack(direction);
					//TODO:validate attack, attack object
				}else if(isUseItem(user_input)){
					//std::cout << "use item called" << std::endl;//DEBUG
					std::cin >> direction;
					currentgame->playerUseItem(direction);
					//TODO:validated use item, use item in direction
				}else if(isRestart(user_input)){
					std::cout << "Are you sure you want to restart? (y/n)" << std::endl;
					while (true){
						std::cin >> user_input;
						if(std::cin.eof()){
							break;
						}
						if (user_input == "y"){
							break;
						}else if (user_input == "n"){
							break;
						}else {
							std::cerr << "Did not recognize input." << std::endl;
						}
					}
					if(user_input == "y"){
						break;
					}
					//TODO:restart game
				}else if (user_input == "stopwander"){
					currentgame->setStopWander();
				}else if (user_input == "stopdeath"){
					currentgame->setStopDeath();
				}else if (isQuit(user_input)){
					std::cout << "Are you sure you want to quit? (y/n)" << std::endl;
					while (true){
						std::cin >> user_input;
						if (user_input == "y" || std::cin.eof()){
							std::cout << "You have chosen to exit. At least you tried." << std::endl;
							gameExitFlag = true;
							break;
						}else if (user_input == "n"){
							break;
						}else {
							std::cerr << "Did not recognize input." << std::endl;
						}
					}
					if(user_input == "y" || std::cin.eof()){
						break;
					}
				}else{
					//std::cout << "Did not recognize input." << std::endl;
				    throw("Did not recognize input");
	            }

	            // check if player is on stairs
	            if(currentgame->onStairs()){
	                if(currentgame->getFloor() == 5){
	                    currentgame->gameWin();
	                    std::cout << "Are you sure you want to restart? (y/n)" << std::endl;
						while (true){
							std::cin >> user_input;
							if(std::cin.eof()){
								break;
							}
							if (user_input == "y"){
								break;
							}else if (user_input == "n"){
								break;
							}else {
								std::cerr << "Did not recognize input." << std::endl;
							}
						}
						if(user_input == "y"){
							break;
						} else if(user_input == "n"){
							gameExitFlag = true;
							break;
						}
	                } else {
	                    currentgame->nextFloor();
	                }
	            }

	            if (user_input != "n"){
	            	currentgame->updateEnemyQueue();
					//TODO: direct enemies 1) check death 2) attack 3) use item 4) move
					currentgame->directEnemies();
					if(currentgame->getPlayer()->getHealth() != 0){
						currentgame->regenerateHealth();
					}
					// std::cout << "player health: " << currentgame->getPlayer()->getHealth() << std::endl; // DEBUG?
					currentgame->nextTurn();
	            	currentgame->updatePlayerStats();
	        	}
	        	currentgame->print();
			}catch(char const * s){ //catch message string -> cerr string
				std::cout << s << std::endl;
			}
	    }

		delete currentgame;
	}
}

#ifndef DRAGON_H
#define DRAGON_H

#include "enemy.h"

class Dragon : public Enemy {
    static bool hostile;
public:
	Dragon();
	~Dragon();

    bool isHostile();
    void setHostile();
    static void setNeutral();
    Cell * randomEnemyMoveLocation();
};

#endif

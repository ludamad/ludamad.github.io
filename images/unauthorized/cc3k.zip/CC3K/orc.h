#ifndef ORC_H
#define ORC_H

#include "enemy.h"

class Orc : public Enemy {
    static bool hostile;
public:
	Orc();
	~Orc();
    bool isHostile();
    void setHostile();
    static void setNeutral();
};

#endif

#ifndef GOBLIN_H
#define GOBLIN_H

#include "enemy.h"

class Goblin : public Enemy {
  static bool hostile;
public:
	Goblin();
	~Goblin();

    bool isHostile();
    void setHostile();
    static void setNeutral();
};
#endif

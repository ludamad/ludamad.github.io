#ifndef ITEM_H
#define ITEM_H

#include <string>

#include "gameObject.h"

class Item : public gameObject {
};

#endif

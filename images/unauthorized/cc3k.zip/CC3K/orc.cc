#include "orc.h"

bool Orc::hostile = true;

Orc::Orc(){
	_display = 'O';
	maxHP = 120;
	baseATK = 30;
	baseDEF = 30;
	HP = maxHP;
    ATK = baseATK;
    DEF = baseDEF;
//    hostile = true;
}

Orc::~Orc(){
}

bool Orc::isHostile(){
    return this->hostile;
}

void Orc::setHostile(){
    hostile = true;
    std::cout << "This is an act of war to every Orc!" << std::endl;
}

void Orc::setNeutral(){
    hostile = false;
}


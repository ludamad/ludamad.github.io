#ifndef CHARACTER_H
#define CHARACTER_H

#include <string>
#include <iostream>
#include <cmath>

#include "potion.h"
#include "gold.h"


#include "gameObject.h"
#include "cell.h"

class gameObject;

class Character : public gameObject {
    protected:
        int HP;
        int maxHP;
        int ATK;
        int baseATK;
        int DEF;
        int baseDEF;
	static bool enemyMobile;

    public:
        Character();
        int getHealth() const;
        int getAttack() const;
        int getDefence() const;
        int getBaseAttack() const;
        int getBaseDefence() const;
        void setHealth(int amt);
        void setAttack(int amt);
        void setDefence(int amt);
        void move(Cell * location);
        int attack(Character * character);
	    void setMobile(bool val);
        void consumeRHPotion();
        void consumeBAPotion();
        void consumeBDPotion();
        void consumePHPotion();
        void consumeWAPotion();
        void consumeWDPotion();
        void takeGoldPile();
        void takeDragonHoard();
        void pickUpPotion(Potion * potion);

        ~Character();
};

#endif

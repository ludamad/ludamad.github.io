#ifndef GAME_H
#define GAME_H

#include <string>
#include <vector>
#include <queue>

#include "potion.h"
#include "gold.h"

#include "knight.h"
#include "wizard.h"
#include "samurai.h"

#include "goblin.h"
#include "gridbug.h"
#include "merchant.h"
#include "dragon.h"
#include "orc.h"

#include "board.h"
#include "cell.h"

#include "PRNG.h"

class Board;

extern PRNG prng;

class Game {
//	Cell** grid;           // The actual grid
	Board * board;
	int dungeonFloor;             // Floor level
	TextDisplay* display;  // The text display.
	Player* player; // player character
    // std::vector<Enemy> enemies; // enemies of board
	int turns;
	std::queue<Enemy*> enemy_list;
	int score;
	bool stopwander;
	bool stopdeath;

public:
	Game(char playerClass, std::string filename);
	~Game();

	void createFloor();

	void nextFloor();
	int getFloor();
    bool onStairs();
	void setFloor(int fl);
	void nextTurn();
//	void customFloor(std::string file);
//	void setgameObject(int x, int y, gameObject * piece);
	Player* getPlayer();
	int getScore();

	Cell* checkPotion(int row, int col);
	void directEnemies();
	void dropItem(int row, int col, std::string enemy_type);
	bool checkGold(std::string dir);
	void movePlayer(std::string dir);
	void moveEnemy();

	void playerAttack(std::string direction);
	void enemyAttack();

	void playerUseItem(std::string direction);
	void GoblinUsePotion();
	void EnemyDropGoldPile();

    void updatePlayerStats();
	void regenerateHealth();

	void print();
	TextDisplay* getTextDisplay();
	void updateEnemyQueue();

	void setStopWander();
	void setStopDeath();
	bool checkStopWander();
	bool checkStopDeath();
	void gameWin();
};

#endif

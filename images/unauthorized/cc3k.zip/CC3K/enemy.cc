#include "enemy.h"

std::string Enemy::getEnemyType(){
	switch(this->getDisplay()){
		case 'X':
			return "Grid Bug";
		break;
		case 'g':
			return "Goblin";
		break;
		case 'M':
			return "Merchant";
		break;
		case 'O':
			return "Orc";
		break;
		case 'D':
			return "Dragon";
		break;
	}
	return " ";
}

bool Enemy::humanNearby(){
    for(int x = 0; x < 8; x++){
      if(this->_location->getNeighbour(x)->isOccupied() &&
	 this->_location->getNeighbour(x)->getContent()->getDisplay() == '@'){
            return true;
        }   
    }
    return false;
}

void Enemy::fullAttack(Character * target){
    int damage = attack(target);
    std::cout << "The evil " << getEnemyType() << " attacks you for " << damage << " damage!" << std::endl;  
}

Cell * Enemy::randomEnemyMoveLocation(){
   int numNeighbours = 8;
   Cell* freesquares[8];
   int freesq = -1;
   int chosen = 0;
   for(int i = 0; i < numNeighbours; i++){
     if (this->_location->getNeighbour(i)->enemyWalkable()){
           freesq++;
           freesquares[freesq] = this->_location->getNeighbour(i);
       }
   }
   if(freesq >= 0){
       if(freesq != 0){
       	 chosen = prng(freesq);
       }
       // std::cout << "x: " << freesquares[chosen]->getX() << " y: " << freesquares[chosen]->getY() << " chosen: " << chosen << std::endl; // DEBUG
       return freesquares[chosen];
    } else {
         return NULL;
    }
}

Enemy::Enemy(){}

Enemy::~Enemy(){}

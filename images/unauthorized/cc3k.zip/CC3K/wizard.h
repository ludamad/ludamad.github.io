#ifndef WIZARD_H
#define WIZARD_H

#include "player.h"

class Wizard : public Player {
public:
	void attack();
	Wizard();
	~Wizard();
};

#endif

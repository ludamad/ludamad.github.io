#include "cell.h"
#include <iostream>

TextDisplay* Cell::txtdisplay;

int MAX_NEIGHBOURS = 8;

Cell::Cell(int x, int y){
    _x = x;
    _y = y;
    _contents = NULL;

    numNeighbours = 0;
}
Cell::Cell(){  // Default constructor
    _contents = NULL;
    _display = ' ';

    numNeighbours = 0;
}

int Cell::getX() const{
    return _x;
}

int Cell::getY() const{
    return _y;
}

void Cell::setX(int x){
    _x = x;
}

void Cell::setY(int y){
    _y = y;
}

void Cell::setCharDisp(char disp){
    this->_display = disp;
//    std::cout << "char set: " << _display << std::endl; // DEBUG
    this->txtdisplay->notifyGameBoard(_x, _y, disp);
}

void Cell::emptyCell(){
//    std::cout << "char set: " << _display << std::endl; // DEBUG
    if (this->_contents){
        delete this->_contents;
        this->_contents = NULL;
        this->txtdisplay->notifyGameBoard(_x, _y, _display);
    }else{
        std::cerr << "Cell empty error" << std::endl;
    }
}

void Cell::setOccupant(gameObject* gobj){
   _contents = gobj;
   if (_contents == NULL){
       this->txtdisplay->notifyGameBoard(_x,_y,this->_display);
   } else {
       this->txtdisplay->notifyGameBoard(_x,_y,_contents->getDisplay());
   }
}

void Cell::clearOccupant(){
    delete _contents;
    setOccupant(NULL);
}

bool Cell::isOccupied(){
    if(_contents == NULL){
        return false;
    } else {
        return true;
    }
}

void Cell::addNeighbour(Cell* neighbour){
    if(numNeighbours < 8){
        neighbours[numNeighbours] = neighbour;
        numNeighbours++;
    }
}

void Cell::addDisplay(TextDisplay* disp){
    txtdisplay = disp;
}

gameObject* Cell::getContent(){
    return this->_contents;
}

bool Cell::dragonNearby(){
    for(int x = 0; x < numNeighbours; x++){
        if(neighbours[x]->_contents != NULL &&
           neighbours[x]->_contents->getDisplay() == 'D'){
            return true;
        }
    }
    return false;
}

Cell * Cell::potionNearby(){
    for(int x = 0; x < numNeighbours; x++){
        if(neighbours[x]->_contents != NULL &&
           neighbours[x]->_contents->getDisplay() == '!'){
            return neighbours[x];
        }
    }
    return NULL;
}

bool Cell::hasEnemy(){
    if (this->_contents == NULL){
        // std::cout << "no content" << std::endl;   // DEBUG
	    return false;
    }

    char display = this->_contents->getDisplay();
    return (display == 'X' ||
            display == 'g' ||
            display == 'M' ||
            display == 'O' ||
            display == 'D');
}

bool Cell::hasPotion(){
    if (this->_contents == NULL){
        // std::cout << "no content" << std::endl;   // DEBUG
    }

    char display = this->_contents->getDisplay();
    return (display == '!');
}

bool Cell::hasGold(){
    if (this->_contents == NULL){
        // std::cout << "no content" << std::endl;   // DEBUG
    }

    char display = this->_contents->getDisplay();
    return (display == '$');
}

bool Cell::playerWalkable(){
    if(this->_display != '-' &&
       this->_display != '|' &&
       this->_display != ' ') {
        return !this->isOccupied();
    } else return false;
}

bool Cell::enemyWalkable(){
    return (this->_display == '.' && !this->isOccupied());
}

bool Cell::isGameBoard(){
    return (_display == '.');
}

bool Cell::isStairs(){
    if(_display == '>'){
        return true;
    } else {
        return false;
    }
}

Cell * Cell::getNeighbour(int x){
    return this->neighbours[x];
}

TextDisplay* Cell::getTextDisplay(){
    return this->txtdisplay;
}

Cell::~Cell(){
    delete _contents;
}

#include "wizard.h"

Wizard::Wizard(){
	maxHP = 60;
	baseATK = 25;
	baseDEF = 0;
	HP =  maxHP;
    ATK = baseATK;
    DEF = baseDEF;
    attack_name = "Infinite Loop Laser";
}

Wizard::~Wizard(){}
